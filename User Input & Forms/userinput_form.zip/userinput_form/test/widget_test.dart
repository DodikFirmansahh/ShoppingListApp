import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shopping_list/main.dart';
import 'package:shopping_list/widgets/grocery_list.dart';

void main() {
  testWidgets('GroceryList menampilkan "No items added yet" saat kosong',
      (WidgetTester tester) async {
    // Membuat dan memicu frame aplikasi kita.
    await tester.pumpWidget(const App());

    // Memverifikasi bahwa keadaan awal menampilkan "No items added yet."
    expect(find.text('No items added yet.'), findsOneWidget);
    expect(find.byType(ListTile), findsNothing);
  });

  testWidgets('Menambahkan item memperbarui GroceryList',
      (WidgetTester tester) async {
    // Membuat dan memicu frame aplikasi kita.
    await tester.pumpWidget(const App());

    // Menekan ikon '+' untuk menavigasi ke halaman item baru.
    await tester.tap(find.byIcon(Icons.add));
    await tester.pumpAndSettle();

    // Memasukkan nama item baru.
    await tester.enterText(find.byType(TextFormField).first, 'Test Item');
    await tester.tap(find.text('Save'));
    await tester.pumpAndSettle();

    // Memverifikasi bahwa daftar sekarang berisi item baru.
    expect(find.text('No items added yet.'), findsNothing);
    expect(find.byType(ListTile), findsOneWidget);
    expect(find.text('Test Item'), findsOneWidget);
  });
}
